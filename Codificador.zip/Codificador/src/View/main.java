
package View;


public class main {
    
    public static void main(String[] args) {
        
        Consola consola1 = new Consola();
        consola1.empezarPrograma();
      
    }
    
}
