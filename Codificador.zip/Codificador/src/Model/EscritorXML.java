package Model;


public class EscritorXML {
    
}
