package Model;

public class EscritorPDF {
    
}
