package Model;

import Controller.DTOAlgoritmos;

public class CodigoTelefonico extends Algoritmo{

    @Override
    public void codificar(DTOAlgoritmos dtoAlgortimo, Alfabeto alfabeto) {
        /*Metodo de Codificar CodigoTelefonico*/
    }

    
    @Override
    public void decodificar(DTOAlgoritmos dtoAlgortimo, Alfabeto alfabeto) {
        /*Metodo de Decodificar CodigoTelefonico*/
    }
    
}
