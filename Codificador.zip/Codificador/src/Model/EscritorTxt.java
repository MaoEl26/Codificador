package Model;

public class EscritorTxt {
    
}
