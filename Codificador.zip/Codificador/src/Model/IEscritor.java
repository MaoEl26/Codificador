
package Model;

public interface IEscritor {
    
}
