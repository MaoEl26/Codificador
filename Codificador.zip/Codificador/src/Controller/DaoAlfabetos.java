package Controller;

import Model.Alfabeto;
import java.util.ArrayList;


public class DaoAlfabetos {

   private static ArrayList<Alfabeto> listaAlfabetos; //Variable con todos los alfabetos creados

    public DaoAlfabetos() {
    }
  
   
   /*Funcion para obtener todos los alfabetos creados*/
    public ArrayList<Alfabeto> getListaAlfabetos() {
        return listaAlfabetos;
    } 
    
    /*Funciones de transaccionalidad sobre alfabetos*/
    public void actualizarAlfabeto(Alfabeto alfabeto){
        
    }
    
    public void crearAlfabeto(Alfabeto alfabeto){
        
    }
    
    public void modificarAlfabeto(Alfabeto alfabeto){
        
    }
    
    public void eliminarAlfabeto(Alfabeto alfabeto){
        
    }
    
    
   
   
    
}
