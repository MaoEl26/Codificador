package Controller;

public interface IValidable {
    
}
